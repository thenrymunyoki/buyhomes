const statusList = [
  "For Rent",
  "Featured",
  "For Sale",
  "Leased",
  "New Addition",
  "Sold",
  "Rental",
  "Reduced",
  "Special Offer",
];

export { statusList };
