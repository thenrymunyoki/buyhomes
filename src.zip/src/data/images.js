const images = [
  "assets/img/categories/1.jpg",
  "assets/img/categories/2.jpg",
  "assets/img/categories/3.jpg",
  "assets/img/categories/4.jpg",
  "assets/img/categories/5.jpg",
  "assets/img/categories/6.jpg",
];

export default images;
