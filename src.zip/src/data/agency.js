const agency =[
    {
        "id": 1,
        "img": "assets/img/companies/1.png",
        "name": "Envato Real Esate",
        "post": "Real Estate",
        "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        "star": true
    },
    {
        "id": 2,
        "img": "assets/img/companies/2.png",
        "name": "Jumpy Co. Real Estate",
        "post": "Real Estate",
        "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        "star": false
    },
    {
        "id": 3,
        "img": "assets/img/companies/3.png",
        "name": "Find Your Home",
        "post": "Real Estate",
        "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        "star": false
    },
    {
        "id": 4,
        "img": "assets/img/companies/4.png",
        "name": "Homy Real Estate",
        "post": "Real Estate",
        "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        "star": true
    }
]
export default agency;