const agents = [
    {
        "id": 1,
        "img": "assets/img/agents/1.jpg",
        "name": "Randy Blue",
        "post": "Expert at Company",
        "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        "star": true
    },
    {
        "id": 2,
        "img": "assets/img/agents/2.jpg",
        "name": "Rinda Flow",
        "post": "Expert at Company",
        "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        "star": false
    },
    {
        "id": 3,
        "img": "assets/img/agents/3.jpg",
        "name": "Gina Mconihon",
        "post": "Expert at Company",
        "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        "star": false
    },
    {
        "id": 4,
        "img": "assets/img/agents/4.jpg",
        "name": "Oliver Rasky",
        "post": "Expert at Company",
        "text": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,",
        "star": true
    }
]

export default agents;