import React, { Component } from 'react';

class Listingsidebar extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default Listingsidebar;