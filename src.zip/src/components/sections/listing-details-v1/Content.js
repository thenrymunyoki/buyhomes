import Banner from "./Banner";
import Listingwrapper from "./Listingwrapper";

const Content = () => {
  return (
    <>
      <Banner />
      <Listingwrapper />
    </>
  );
};

export default Content;
